package in.ineuron;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Q24SpringRestInsertDataApplication {

	public static void main(String[] args) {
		SpringApplication.run(Q24SpringRestInsertDataApplication.class, args);
	}

}
