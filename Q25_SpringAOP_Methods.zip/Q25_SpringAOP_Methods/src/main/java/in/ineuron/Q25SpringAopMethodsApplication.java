package in.ineuron;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Q25SpringAopMethodsApplication {

	public static void main(String[] args) {
		SpringApplication.run(Q25SpringAopMethodsApplication.class, args);
	}

}
