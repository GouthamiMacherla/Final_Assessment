package in.ineuron;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Q13SpringRestPostgreSqlApplication {

	public static void main(String[] args) {
		SpringApplication.run(Q13SpringRestPostgreSqlApplication.class, args);
	}

}
