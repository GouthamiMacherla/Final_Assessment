package in.ineuron.controller;

import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class CreatePostServlet
 */
@WebServlet("/PostServlet")
public class CreatePostServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		
		String title = request.getParameter("title");
		String description = request.getParameter("description");
		String content = request.getParameter("content");
		
		//validate input (add appropriate validation logic)
		try {
			//Establish database connection
			Connection connection = DriverManager.getConnection("jdbc:mysql:///pwskills", "root", "MacherlaGouthami_3!");
			
			//Insert blog posts into the database
			PreparedStatement statement = connection.prepareStatement("INSERT INTO blog_posts(title,description,content) VALUES (?,?,?)");
			
			
			statement.setString(1,title);
			statement.setString(2,description);
			statement.setString(3,content);
			statement.executeUpdate();
			
			//close resources
			statement.close();
			connection.close();
		}catch(SQLException e) {
			e.printStackTrace();
			//Handle database errors
		}
		
		response.sendRedirect("view-posts.jsp");
	}

}
