package in.ineuron.controller;

import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import in.ineuron.model.Page;

import java.util.List;
import java.util.ArrayList;

/**
 * Servlet implementation class ViewPostsServlet
 */
@WebServlet("/ViewPosts")
public class ViewPostsServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
	     
		List<Page> pages = new ArrayList<>();
		
		try {
			//Establish database connection
			Connection connection = DriverManager.getConnection("jdbc:mysql:///pwskills", "root","MacherlaGouthami_3!");
			
			//Retrieve all blog posts from the database
			Statement statement = connection.createStatement();
			ResultSet resultset = statement.executeQuery("SELECT * FROM blog_posts");
			
			
			//Create post objects from the resultset
			while(resultset.next()) {
				int id =resultset.getInt("id");
				String title = resultset.getString("title");
				String description = resultset.getString("description");
				String content = resultset.getString("content");
				
	            Page pg = new Page(id,title,description,content);
	            pages.add(pg);
			}
			//close resources
			resultset.close();
			statement.close();
			connection.close();
			
		}catch(SQLException e) {
			e.printStackTrace();
			//Handle database errors
		}
		
		request.setAttribute("pages", pages);
		request.getRequestDispatcher("view-posts.jsp").forward(request, response);
		
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

}
